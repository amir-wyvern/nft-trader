"""
Provides pyhmy version information.
"""

# This file is auto-generated! Do not edit!
# Use `python -m incremental.update pyhmy` to change this file.

from incremental import Version

__version__ = Version('pyhmy', 20, 5, 20)
__all__ = ["__version__"]
